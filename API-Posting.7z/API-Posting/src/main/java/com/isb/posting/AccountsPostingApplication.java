package com.isb.posting;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AccountsPostingApplication {

	public static void main(String[] args) {
		SpringApplication.run(AccountsPostingApplication.class, args);
		
	}

}
