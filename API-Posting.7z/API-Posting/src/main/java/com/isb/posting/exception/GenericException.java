package com.isb.posting.exception;

public interface GenericException {

	public int getCode();

	public String getMessage();
	
	public String getLevel();
	
	public String getDescription();
	
}
